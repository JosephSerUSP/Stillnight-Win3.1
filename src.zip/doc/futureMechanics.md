-Sacrifice Rewards:
Instead of simple Gold, Sacrifice will yield rewards based on the creature sacrificed and its power.
This is the only way to access some content such as Evolution materials, equipment or skill books.

-Quests: 
Inspired by Diablo, mostly. NPCs can yield the player Quests, which can be tracked in a dedicated Quest window. 


-Items:
Onyx Lamp: Inspired by Diabolos's lamp in FFVIII. Use it to trigger a difficult boss fight against a rare demon. Win to recruit.