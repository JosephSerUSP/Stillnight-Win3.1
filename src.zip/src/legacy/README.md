# Legacy Code

This directory contains legacy code that is being phased out or referenced for migration.
