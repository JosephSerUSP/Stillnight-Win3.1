import { InterpreterSystem } from "../engine/systems/interpreter.js";
import { randInt, pickWeighted, random } from "../core/utils.js";
import { AudioAdapter } from "./audio_adapter.js";
import {
  createInteractiveLabel,
  renderCreatureInfo
} from "../presentation/windows/index.js";
import { Game_Battler } from "../objects/battler.js";
import { QuestSystem } from "../engine/systems/quest.js";

/**
 * @class InterpreterAdapter
 * @description Adapter that bridges Scene_Map and InterpreterSystem.
 * Replaces the old Logic-heavy Game_Interpreter.
 */
export class InterpreterAdapter {
    /**
     * Creates a new InterpreterAdapter.
     * @param {Object} sceneContext - The scene context (Scene_Map interface).
     */
    constructor(sceneContext) {
        this.scene = sceneContext;
        this.system = new InterpreterSystem();
        this._onRecruitCallback = null;
        this._activeNpc = null;
    }

    get dataManager() { return this.scene.dataManager; }
    get windowManager() { return this.scene.windowManager; }
    get sceneManager() { return this.scene.sceneManager; }
    get party() { return this.scene.party; }
    get map() { return this.scene.map; }
    get session() { return this.scene.session; }

    /**
     * Executes a map event action using the system.
     * @param {Object} action - The action object.
     * @param {import("../objects/objects.js").Game_Event} event - The source event.
     */
    execute(action, event) {
        // Construct a session object for the system
        const session = {
            party: this.party,
            map: this.map, // Adapter, might need unwrapping or system handles it
            // Add other needed session state
        };

        const events = this.system.executeAction(action, event, session);
        this.processSystemEvents(events);
    }

    /**
     * Executes a sequence of commands.
     * @param {Array} sequence
     * @param {Object} eventContext
     */
    async executeSequence(sequence, eventContext) {
        // Simple shim for now: treating sequence as single action list is not quite right
        // but Scene_Map calls executeSequence(event.sequence, event)
        // InterpreterSystem.runUntilPause uses state.
        // We need to manage state if we want async execution.

        // For now, let's assume direct execution via legacy method or new system
        // The previous Game_Interpreter didn't show executeSequence implementation in the file I read?
        // Wait, I missed executeSequence in the read_file output?
        // Ah, the read_file output was truncated?
        // "execute(action, event)" was there.
        // Scene_Map calls "executeSequence".
        // I need to implement executeSequence.

        // Let's implement it using InterpreterSystem.runUntilPause
        const session = {
            party: this.party,
            map: this.map
        };

        // Use a throwaway state for this sequence
        // Note: This doesn't support save/load of interpreter state during sequence yet
        // unless we store state in this adapter.

        // The legacy manager/interpreter.js I read had "execute(action, event)".
        // It did NOT show executeSequence. Maybe it was inherited or I missed it.
        // But Scene_Map calls it.
        // I will implement it.

        // To properly support async, we loop.
        const state = new (await import("../engine/session/interpreter_state.js")).InterpreterState();
        state.start(sequence, eventContext);

        while(state.stack.length > 0) {
            const events = this.system.runUntilPause(state, session);
            this.processSystemEvents(events);

            if (state.waitMode === 'time') {
                await new Promise(r => setTimeout(r, state.waitValue));
                state.waitMode = null;
            } else if (state.waitMode === 'input') {
                // Not supported in this simple loop yet
                break;
            }
            // Yield to event loop to allow UI updates
            await new Promise(r => setTimeout(r, 0));
        }
    }

    // Alias for legacy support if needed
    executeEvent(event) {
        // If event object is passed, extract action/sequence
        if (event.sequence) {
            this.executeSequence(event.sequence, event);
        } else {
            // Treat event properties as action
            this.execute(event, event);
        }
    }

    /**
     * Processes events returned by InterpreterSystem.
     * @param {Array} events
     */
    processSystemEvents(events) {
        for (const e of events) {
            switch (e.type) {
                case 'LOG':
                    this.scene.logMessage(e.text);
                    break;
                case 'SET_STATUS':
                    this.scene.setStatus(e.text);
                    break;
                case 'PLAY_SOUND':
                    AudioAdapter.play(e.name);
                    break;
                case 'UPDATE_UI':
                    this.scene.updateAll();
                    break;
                case 'GAIN_XP':
                    this.scene.gainXp(e.member, e.amount);
                    break;
                case 'APPLY_MOVE_PASSIVES':
                    this.scene.applyMovePassives();
                    break;
                case 'BATTLE_START':
                    this.scene.startBattle(e.x, e.y);
                    break;
                case 'SHOP_START':
                    this.scene.startShop(e.shopId);
                    break;
                case 'SHRINE_OPEN':
                    this._openShrineEvent();
                    break;
                case 'RECRUIT_OPEN':
                    this._openRecruitEvent(e.options);
                    break;
                case 'NPC_DIALOGUE_OPEN':
                    this._openNpcEvent(e.id);
                    break;
                case 'DESCEND':
                    this._descendStairs();
                    break;
                case 'TREASURE_OPEN':
                    this._openTreasureEvent();
                    break;
                case 'TRAP_TRIGGER':
                    this._triggerTrap(e.action);
                    break;
                case 'WALL_BROKEN':
                    this._resolveBrokenWall(e.x, e.y);
                    break;
                default:
                    console.warn(`InterpreterAdapter: Unhandled event type '${e.type}'`);
            }
        }
    }

    // --- Legacy Implementation Details (UI stuff) ---

    _resolveBrokenWall(x, y) {
        this.map.removeEvent(this.map.floorIndex, x, y);
        const floor = this.map.floors[this.map.floorIndex];
        floor.tiles[y][x] = '.';
        floor.visited[y][x] = true;
        this.scene.updateGrid();
        this.scene.updateAll();
    }

    _descendStairs() {
        if (this.map.floorIndex + 1 >= this.map.floors.length) {
            this.scene.logMessage("[Floor] You find no further descent. The run ends here.");
            this.scene.runActive = false;
            this.scene.setStatus("No deeper floors. Run over (for now).");
            this.scene.updateAll();
            return;
        }
        this.map.floorIndex++;
        if (this.map.floorIndex > this.map.maxReachedFloorIndex) {
            this.map.maxReachedFloorIndex = this.map.floorIndex;
        }
        const f = this.map.floors[this.map.floorIndex];
        f.discovered = true;
        this.map.playerX = f.startX;
        this.map.playerY = f.startY;
        this.map.revealAroundPlayer();
        this.scene.logMessage(`[Floor] You descend to: ${f.title}`);
        this.scene.logMessage(`[Floor] ${f.intro}`);
        this.scene.setStatus("Descending.");
        this.scene.updateAll();
        this.scene.checkMusic();
    }

    _openShrineEvent() {
        const scenarios = this.dataManager.events.filter(e => e.type === 'shrine_scenario');
        if (scenarios.length === 0) {
            this.scene.logMessage(this.dataManager.terms.shrine.silent);
            return;
        }
        const ev = scenarios[randInt(0, scenarios.length - 1)];

        const choices = ev.choices.map(ch => ({
            label: ch.label,
            onClick: async () => {
                const footer = this.scene.hudManager.eventWindow.footer;
                const buttons = footer.querySelectorAll('button');
                buttons.forEach(b => b.disabled = true);

                this.scene.hudManager.eventWindow.appendLog(`> ${ch.label}`);
                this.clearEventTile();

                await this.applyEventEffect(ch.effect);
                this.scene.hudManager.eventWindow.updateChoices([{
                    label: "Exit Shrine",
                    onClick: () => this.closeEvent()
                }]);
            }
        }));

        this.scene.hudManager.eventWindow.show({
            title: ev.title,
            description: ev.description,
            image: ev.image || "shrine.png",
            style: 'terminal',
            choices: choices
        });
        this.windowManager.push(this.scene.hudManager.eventWindow);

        this.scene.setStatus("Shrine event.");
        AudioAdapter.play('UI_SELECT');
    }

    async applyEventEffect(effect) {
        const log = (msg) => this.scene.logMessage(msg);
        const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

        await delay(300);

        switch (effect.type) {
        case "hp":
            this.party.members.forEach((m) => {
                m.hp += effect.value;
                if (m.hp > m.maxHp) m.hp = m.maxHp;
                if (m.hp < 0) m.hp = 0;
            });
            log(this.dataManager.terms.shrine.hp_change.replace("{0}", effect.value));
            break;
        case "maxHp":
            this.party.members.forEach((m) => (m.maxHp += effect.value));
            log(this.dataManager.terms.shrine.max_hp_change.replace("{0}", effect.value));
            break;
        case "xp":
            this.party.members.forEach((m) => this.scene.gainXp(m, effect.value));
            log(this.dataManager.terms.shrine.xp_gain.replace("{0}", effect.value));
            break;
        case "gold":
            this.party.gold += effect.value;
            log(this.dataManager.terms.shrine.gold_gain.replace("{0}", effect.value));
            if (effect.onSuccess) {
            await this.applyEventEffect(effect.onSuccess);
            }
            break;
        case "message":
            log(effect.value);
            break;
        case "random": {
            const roll = random();
            let outcome;
            for (const o of effect.outcomes) {
            if (roll < o.chance) {
                outcome = o;
                break;
            }
            }
            if (outcome) {
            await this.applyEventEffect(outcome.effect);
            }
            break;
        }
        case "multi":
            for (const e of effect.effects) {
                await this.applyEventEffect(e);
            }
            break;
        }
        this.scene.updateAll();
    }

    _triggerTrap(action) {
        this.scene.hudManager.eventWindow.show({
            title: "Trap!",
            description: action.message || "You triggered a trap!",
            image: "trap.png",
            style: 'terminal',
            choices: [{
                label: "Ouch...",
                onClick: () => this.resolveTrap(action)
            }]
        });

        this.scene.hudManager.eventWindow.onUserClose = () => {
            this.resolveTrap(action);
        };

        this.windowManager.push(this.scene.hudManager.eventWindow);
        AudioAdapter.play('DAMAGE');
    }

    async resolveTrap(action) {
        this.scene.hudManager.eventWindow.onUserClose = this.closeEvent.bind(this);
        const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
        try {
            const dmg = action.damage || 5;
            this.scene.hudManager.eventWindow.appendLog(`> Ouch...`);
            await delay(500);

            this.party.members.forEach(m => {
                m.hp = Math.max(0, m.hp - dmg);
            });

            this.scene.logMessage(`The party takes ${dmg} damage.`);
            this.scene.checkPermadeath();
            AudioAdapter.play('DAMAGE');
            this.scene.updateAll();

            this.scene.hudManager.eventWindow.updateChoices([{
                label: "Close",
                onClick: () => this.scene.hudManager.eventWindow.onUserClose()
            }]);
        } catch (e) {
            console.error(e);
            this.scene.hudManager.eventWindow.appendLog("Error in resolveTrap: " + e);
        }
    }

    _openTreasureEvent() {
        const floor = this.map.floors[this.map.floorIndex];
        let possibleItems = floor.treasures || [];

        if (!possibleItems || possibleItems.length === 0) {
            possibleItems = this.dataManager.items.filter(i => i.type !== 'key').map(i => i.id);
        }

        let itemId;
        if (typeof possibleItems[0] === 'string') {
            itemId = possibleItems[randInt(0, possibleItems.length - 1)];
        } else {
            const picked = pickWeighted(possibleItems);
            itemId = picked ? picked.id : null;
        }

        if (!itemId && possibleItems.length > 0) {
            if (typeof possibleItems[0] === 'string') itemId = possibleItems[0];
            else itemId = possibleItems[0].id;
        }

        const item = this.dataManager.items.find(i => i.id === itemId) || this.dataManager.items[0];

        this.party.inventory.push(item);
        this.clearEventTile();

        const itemLabel = createInteractiveLabel(item, 'item');

        this.scene.hudManager.eventWindow.show({
            title: "Treasure Found!",
            description: [
                "You found:",
                itemLabel,
                "",
                item.description
            ],
            image: "treasure.png",
            style: 'terminal',
            choices: [{
                label: "Take",
                onClick: () => this.closeEvent()
            }]
        });
        this.windowManager.push(this.scene.hudManager.eventWindow);
        AudioAdapter.play('ITEM_GET');
        this.scene.updateAll();
    }

    closeEvent() {
        this.windowManager.close(this.scene.hudManager.eventWindow);
        if (this.scene.hudManager.questWindow) {
            this.windowManager.close(this.scene.hudManager.questWindow);
        }
        this._activeNpc = null;
        this.scene.updateAll();
    }

    _openRecruitEvent(options = {}) {
        const { forcedId, cost: forcedCost, onRecruit } = options;
        this._onRecruitCallback = onRecruit;

        let recruit;
        if (forcedId) {
             recruit = this.dataManager.actors.find(a => a.id === forcedId);
        }

        if (!recruit) {
            const floor = this.map.floors[this.map.floorIndex];
            if (floor && floor.recruits && floor.recruits.length > 0) {
                const recruitId = floor.recruits[randInt(0, floor.recruits.length - 1)];
                recruit = this.dataManager.actors.find(a => a.id === recruitId);
            }
            if (!recruit) {
                const availableCreatures = this.dataManager.actors.filter(creature => creature.isRecruitable);
                if (availableCreatures.length === 0) {
                    this.scene.logMessage(this.dataManager.terms.recruit.no_one_here);
                    return;
                }
                recruit = availableCreatures[randInt(0, availableCreatures.length - 1)];
            }
        }

        const cost = forcedCost !== undefined ? forcedCost : randInt(25, 75);

        renderCreatureInfo(this.scene.hudManager.recruitWindow.bodyEl, recruit, {
            showElement: true,
            showEquipment: true,
            showPassives: true,
            showSkills: true,
            showFlavor: true,
            dataManager: this.dataManager
        });

        this.scene.hudManager.recruitWindow.buttonsEl.innerHTML = "";
        const joinBtn = document.createElement("button");
        joinBtn.className = "win-btn";
        joinBtn.textContent = `Pay ${cost} Gold`;
        joinBtn.addEventListener("click", () => {
            if (this.party.gold >= cost) {
                this.party.gold -= cost;
                this.attemptRecruit(recruit);
            } else {
                this.scene.logMessage(`[Recruit] You don't have enough gold.`);
                this.closeRecruitEvent();
            }
        });
        const declineBtn = document.createElement("button");
        declineBtn.className = "win-btn";
        declineBtn.textContent = "Decline";
        declineBtn.addEventListener("click", () => {
            this.scene.logMessage(`[Recruit] You decline ${recruit.name}'s offer.`);
            this.closeRecruitEvent();
        });
        this.scene.hudManager.recruitWindow.buttonsEl.appendChild(joinBtn);
        this.scene.hudManager.recruitWindow.buttonsEl.appendChild(declineBtn);

        this.windowManager.push(this.scene.hudManager.recruitWindow);
        this.scene.setStatus("Recruit encountered.");
        AudioAdapter.play('UI_SELECT');
    }

    closeRecruitEvent() {
        this._onRecruitCallback = null;
        this.windowManager.close(this.scene.hudManager.recruitWindow);
        this.scene.setStatus("Exploration");
    }

    _openNpcEvent(npcId) {
        const npc = this.dataManager.npcs[npcId];
        if (!npc) {
            console.warn(`NPC '${npcId}' not found.`);
            return;
        }

        this._activeNpc = { id: npcId, data: npc };
        // For now, we only show the initial state.
        // Complex state machine logic should be handled here or in a dedicated NpcInteractionSystem.
        // We will implement a basic state handler here.
        this._runNpcState(npc, npc.initialState || 'default');
    }

    _runNpcState(npc, stateId) {
        const stateData = npc.states[stateId];
        if (!stateData) {
            console.warn(`NPC state '${stateId}' not found for '${npc.name}'`);
            this.closeEvent();
            return;
        }

        this._activeNpc = { id: this._activeNpc?.id || npc.name, data: npc };

        // Evaluate condition if present
        if (stateData.condition) {
            const result = this._checkCondition(stateData.condition);
            if (result && stateData.trueState) {
                this._runNpcState(npc, stateData.trueState);
                return;
            } else if (!result && stateData.falseState) {
                this._runNpcState(npc, stateData.falseState);
                return;
            }
        }

        const choices = (stateData.choices || []).map(ch => ({
            label: ch.label,
            onClick: () => this._handleNpcChoice(npc, ch)
        }));

        this.scene.hudManager.eventWindow.show({
            title: npc.name,
            description: stateData.text,
            layout: npc.layout || 'visual_novel',
            portrait: npc.portrait,
            // Pass speakers if defined in state
            speakers: stateData.speakers,
            style: npc.style || 'terminal',
            choices: choices
        });

        if (!this.windowManager.stack.includes(this.scene.hudManager.eventWindow)) {
            this.windowManager.push(this.scene.hudManager.eventWindow);
        }

        this.scene.setStatus(`Talking to ${npc.name}.`);
        AudioAdapter.play('UI_SELECT');
    }

    _transitionNpcState(nextStateId) {
        if (this._activeNpc && nextStateId) {
            this._runNpcState(this._activeNpc.data, nextStateId);
        } else {
            this.closeEvent();
        }
    }

    _handleNpcChoice(npc, choice) {
        // Explicit Close
        if (choice.action === 'close') {
            this.closeEvent();
            return;
        }

        // Actions that can coexist with state changes or other flows
        if (choice.action === 'shop') {
             this.scene.startShop(choice.shopId);
        } else if (choice.action === 'teleport') {
            this.closeEvent();
            // TODO: Teleport logic
            this.scene.logMessage("Teleporting...");
            return;
        }

        // Quest actions override standard flow as they invoke sub-windows with their own callbacks
        if (choice.action === 'quest') {
            this._openQuestOffer(choice.questId, choice);
            return;
        } else if (choice.action === 'questComplete') {
            this._completeQuest(choice.questId, choice);
            return;
        }

        // State Transition
        if (choice.nextState) {
            this._runNpcState(npc, choice.nextState);
        } else if (choice.action !== 'shop') {
             // If no next state and not a persisting action (like shop), close by default.
             this.closeEvent();
        }
    }

    _getQuestDefinition(questId) {
        if (!questId || !this.dataManager.quests) return null;
        const quests = this.dataManager.quests;
        const quest = quests[questId] || (Array.isArray(quests) ? quests.find(q => q.id === questId) : null);
        if (!quest) return null;
        return { id: questId, ...quest };
    }

    _enrichQuestRewards(questDef) {
        if (!questDef.rewards || !Array.isArray(questDef.rewards.items)) return questDef;

        const items = (this.dataManager.items || []);
        const enriched = questDef.rewards.items.map(r => {
            const itemDef = items.find(i => i.id === r.id);
            return {
                ...r,
                name: r.name || itemDef?.name,
                icon: r.icon || itemDef?.icon,
            };
        });

        return {
            ...questDef,
            rewards: {
                ...questDef.rewards,
                items: enriched
            }
        };
    }

    _openQuestOffer(questId, choice = {}) {
        const quest = this._getQuestDefinition(questId);
        if (!quest) {
            console.warn(`Quest '${questId}' not found.`);
            return;
        }

        const status = QuestSystem.getStatus(this.session.quests, questId);
        const questData = this._enrichQuestRewards(quest);

        const onAccept = () => {
            const result = QuestSystem.acceptQuest(this.session.quests, questId);
            if (result.ok) {
                this.scene.logMessage(`[Quest] Accepted: ${quest.name}.`);
                this.scene.setStatus(`Quest accepted: ${quest.name}`);
                AudioAdapter.play('UI_SELECT');
                this.windowManager.close(this.scene.hudManager.questWindow);
                if (choice.acceptState || choice.nextState) {
                    this._transitionNpcState(choice.acceptState || choice.nextState);
                }
            } else {
                this.scene.logMessage(`[Quest] ${quest.name} is already ${result.reason}.`);
            }
        };

        const onDecline = () => {
            this.windowManager.close(this.scene.hudManager.questWindow);
            if (choice.declineState) {
                this._transitionNpcState(choice.declineState);
            }
        };

        this.scene.hudManager.questWindow.show({
            quest: questData,
            npcName: this._activeNpc?.data?.name,
            status,
            onAccept,
            onDecline,
        });
        if (!this.windowManager.stack.includes(this.scene.hudManager.questWindow)) {
            this.windowManager.push(this.scene.hudManager.questWindow);
        }
    }

    _completeQuest(questId, choice = {}) {
        const quest = this._getQuestDefinition(questId);
        if (!quest) {
            console.warn(`Quest '${questId}' not found.`);
            return;
        }

        const result = QuestSystem.completeQuest(this.session.quests, quest, this.party, this.dataManager);
        if (result.ok) {
            this.scene.logMessage(`[Quest] Completed: ${quest.name}.`);
            this.scene.setStatus(`${quest.name} completed.`);
            AudioAdapter.play('ITEM_GET');
            if (choice.completeState || choice.nextState) {
                this._transitionNpcState(choice.completeState || choice.nextState);
            }
            this.scene.updateAll();
            return;
        }

        if (result.reason === 'requirements') {
            this.scene.logMessage(`[Quest] You still need to bring the requested item.`);
        } else if (result.reason === 'completed') {
            this.scene.logMessage(`[Quest] ${quest.name} is already complete.`);
        } else {
            this.scene.logMessage(`[Quest] ${quest.name} is not active.`);
        }
    }

    _checkCondition(conditionString) {
        if (!conditionString) return true;
        const [type, ...rest] = conditionString.split(':');

        switch (type) {
            case 'hasItem':
                return this.party.hasItem(rest[0]);
            case 'questStatus': {
                const questId = rest[0];
                const desired = rest[1] || 'active';
                return QuestSystem.getStatus(this.session.quests, questId) === desired;
            }
            case 'questActive':
                return QuestSystem.getStatus(this.session.quests, rest[0]) === 'active';
            case 'questCompleted':
                return QuestSystem.getStatus(this.session.quests, rest[0]) === 'completed';
            default:
                return false;
        }
    }

    clearEventTile() {
        if (this.scene.currentInteractionEvent) {
            this.map.removeEvent(this.map.floorIndex, this.scene.currentInteractionEvent.x, this.scene.currentInteractionEvent.y);
            this.scene.currentInteractionEvent = null;
        }
        this.scene.updateGrid();
    }

    attemptRecruit(recruit) {
        if (this.party.hasEmptySlot()) {
            this.party.addMember(Game_Battler.create(recruit));
            this.scene.logMessage(`[Recruit] ${recruit.name} joins your party.`);
            this.scene.setStatus(
                this.dataManager.terms.recruit.recruited.replace("{0}", recruit.name)
            );

            if (this._onRecruitCallback) {
                this._onRecruitCallback();
                this._onRecruitCallback = null;
            }

            this.clearEventTile();
            this.closeRecruitEvent();
            this.scene.updateParty();
            return;
        }
        this.scene.hudManager.recruitWindow.bodyEl.innerHTML =
            this.dataManager.terms.recruit.party_full;
        this.scene.hudManager.recruitWindow.buttonsEl.innerHTML = "";
        this.party.members.forEach((m, idx) => {
            const btn = document.createElement("button");
            btn.className = "win-btn";
            btn.textContent = m.name;
            btn.addEventListener("click", () => {
                this.replaceMemberWithRecruit(idx, recruit);
            });
            this.scene.hudManager.recruitWindow.buttonsEl.appendChild(btn);
        });
        const cancelBtn = document.createElement("button");
        cancelBtn.className = "win-btn";
        cancelBtn.textContent = "Cancel";
        cancelBtn.addEventListener("click", () => {
            this.scene.logMessage(this.dataManager.terms.recruit.decide_not_to_replace);
            this.closeRecruitEvent();
        });
        this.scene.hudManager.recruitWindow.buttonsEl.appendChild(cancelBtn);
    }

    replaceMemberWithRecruit(index, recruit) {
        const replaced = this.party.members[index];
        this.scene.logMessage(
            this.dataManager.terms.recruit.replace_member
                .replace("{0}", replaced.name)
                .replace("{1}", recruit.name)
        );
        this.party.replaceMember(index, Game_Battler.create(recruit));

        if (this._onRecruitCallback) {
            this._onRecruitCallback();
            this._onRecruitCallback = null;
        }

        this.clearEventTile();
        this.scene.updateParty();
        this.closeRecruitEvent();
    }
}
