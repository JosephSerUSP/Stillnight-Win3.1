# Engine\n\nThe core engine logic, decoupled from presentation.
